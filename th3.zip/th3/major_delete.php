<?php
// Kết nối cơ sở dữ liệu
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qlsv";

$conn = new mysqli($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Kiểm tra xem ID có được truyền qua URL hay không
$id = isset($_POST['id']) ? $_POST['id'] : '';

    // Chuẩn bị câu lệnh xóa chuyên ngành
    $sql = "DELETE FROM major WHERE ID='".$id."'";
if ($conn->query($sql) == TRUE) {
 header('Location: major_index.php');
} else {
 echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();
?>