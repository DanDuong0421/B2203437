<!DOCTYPE HTML>
<html>
<body>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qlsv";

// Kết nối cơ sở dữ liệu
$conn = new mysqli($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Lấy danh sách chuyên ngành từ bảng major
$sql = "SELECT id, name_major FROM major";
$result = $conn->query($sql);

?>
<form action="luu.php" method="post">
    Name: <input type="text" name="name"><br>
    E-mail: <input type="text" name="email"><br>
    Birthday: <input type="date" name="birth"><br>
    
    <!-- Combobox chọn chuyên ngành -->
    Chuyên Ngành:
    <select name="major_id">
        <?php
        // Lặp qua các chuyên ngành và hiển thị dưới dạng <option>
        while($row = $result->fetch_assoc()) {
            echo "<option value='" . $row['id'] . "'>" . $row['name_major'] . "</option>";
        }
        ?>
    </select><br>

    <input type="submit">
</form>

<?php
$conn->close();
?>
</body>
</html>
