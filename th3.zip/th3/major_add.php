<?php
// Kết nối cơ sở dữ liệu
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qlsv";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name_major = $_POST['name_major'];

    // Thêm dữ liệu vào bảng major
    $sql = "INSERT INTO major (name_major) VALUES ('$name_major')";

    if ($conn->query($sql) === TRUE) {
        echo "Thêm chuyên ngành thành công.";
        header("Location: major_index.php"); // Chuyển hướng về trang danh sách major
    } else {
        echo "Lỗi: " . $conn->error;
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thêm Chuyên Ngành</title>
</head>
<body>
    <h2>Thêm Chuyên Ngành</h2>
    <form method="post" action="major_add.php">
        <label for="name_major">Tên Chuyên Ngành:</label>
        <input type="text" id="name_major" name="name_major" required><br><br>
        <input type="submit" value="Thêm">
    </form>
</body>
</html>
