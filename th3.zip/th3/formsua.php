<!DOCTYPE HTML>
<html>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qlsv";

// Kết nối cơ sở dữ liệu
$conn = new mysqli($servername, $username, $password, $dbname);

// Kiểm tra kết nối
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Lấy ID sinh viên từ URL hoặc từ form POST
$id = isset($_POST['id']) ? $_POST['id'] : '';

// Lấy thông tin sinh viên theo ID
$sql = "SELECT * FROM student WHERE id='".$id."'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

// Lấy danh sách chuyên ngành từ bảng major
$sql_major = "SELECT id, name_major FROM major";
$result_major = $conn->query($sql_major);
?>

<body>
<form action="sua.php" method="post">
    ID: <input type="text" name="id" value="" readonly><br>
    Name: <input type="text" name="fullname" value=""><br>
    E-mail: <input type="text" name="email" value=""><br>
    Birthday: <input type="date" name="birth" value=""><br>
    
    <!-- Combobox chọn chuyên ngành -->
    Chuyên Ngành:
    <select name="major_id">
        <?php
        // Lặp qua các chuyên ngành và hiển thị dưới dạng <option>
        while ($major = $result_major->fetch_assoc()) {
            // Kiểm tra nếu chuyên ngành đã được chọn
            $selected = ($major['id'] == $row['major_id']) ? "selected" : "";
            echo "<option value='" . $major['id'] . "' $selected>" . $major['name_major'] . "</option>";
        }
        ?>
    </select><br>

    <input type="submit" value="Cập nhật">
</form>

<?php
// Đóng kết nối cơ sở dữ liệu
$conn->close();
?>
</body>
</html>
