<?php
// Kết nối cơ sở dữ liệu
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qlsv";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Lấy danh sách các chuyên ngành
$sql = "SELECT * FROM major";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Danh sách Chuyên Ngành</title>
</head>
<body>
    <h2>Danh sách Chuyên Ngành</h2>
    <a href="major_add.php">Thêm mới chuyên ngành</a>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Tên Chuyên Ngành</th>
            <th>Thao tác</th>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "<tr><td>" . $row["id"] . "</td><td>" . $row["name_major"] . "</td>";
                echo "<td><a href='major_edit.php?id=" . $row["id"] . "'>Sửa</a> | <a href='major_delete.php?id=" . $row["id"] . "'>Xóa</a></td></tr>";
            }
        } else {
            echo "<tr><td colspan='3'>Không có dữ liệu</td></tr>";
        }
        ?>
    </table>
</body>
</html>
<?php
$conn->close();
?>
