<!DOCTYPE HTML>
<html>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qlsv";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$id = isset($_POST['id']) ? $_POST['id'] : '';
$sql = "select * FROM major WHERE ID='".$id."'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
?>
<body>
<?php print_r($row)?>
<form action="edit.php" method="post">
ID:<input type="text" name="id" value=""><br>
Name Major: <input type="text" name="name_major" value=""><br>
<input type="submit">
</form>
</body>
</html>